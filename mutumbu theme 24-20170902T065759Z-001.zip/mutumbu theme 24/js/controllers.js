angular.module('starter.controllers', [])


.controller('register', function($scope,$rootScope, $stateParams) {
	$rootScope.showMenu=true;
})

.controller('login', function($scope,$rootScope, $stateParams) {
	$rootScope.showMenu=false;
})
.controller('home', function($scope,$rootScope, $stateParams) {
	$rootScope.showMenu=true;
})
.controller('video', function($scope,$rootScope, $stateParams) {
	$rootScope.showMenu=true;
})

.controller('setting', function($scope,$rootScope, $stateParams) {
	$rootScope.showMenu=true;
})
.controller('detail', function($scope,$rootScope, $stateParams) {
	$rootScope.showMenu=true;
})
.controller('contact', function($scope,$rootScope, $stateParams) {
	$rootScope.showMenu=true;
})
  