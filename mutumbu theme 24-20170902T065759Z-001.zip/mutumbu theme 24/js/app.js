// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers'])
/* //if use wakanda platform 
    angular.module('starter', ['ionic', 'starter.controllers','wakanda'])
*/
.run(function($ionicPlatform,$rootScope,$ionicPopup,$ionicModal,$location,$ionicHistory) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
	$rootScope.icon_Activecolor=false;
	$rootScope.icon_Active = function() {
	if($rootScope.icon_Activecolor){
		$rootScope.icon_Activecolor=false;
		}
	else{
		$rootScope.icon_Activecolor=true;
		}	
	};
    
    
    
$rootScope.setting=[{title:"Random news"},{title:"Local news"},{title:"Sport news"},{title:"Notification allert"}]	
	
 $rootScope.list=[{id:"1",img:"img/003.png"},{id:"2",img:"img/002.png"},{id:"3",img:"img/001.png"},{id:"4",img:"img/003.png"},{id:"5",img:"img/002.png"},{id:"1",img:"img/003.png"},{id:"2",img:"img/002.png"},{id:"3",img:"img/001.png"},{id:"4",img:"img/003.png"},{id:"5",img:"img/002.png"}]	
	
  $rootScope.items=[{id:"1",img:"img/001.png",title:"14 powerful photos that will change how you think about the world today"},
                  {id:"2",img:"img/003.png",title:"new zealand nature landscapes valley hills mountaisn fields sky clouds trees roads wallpaper"},{id:"3",img:"img/002.png",title:"nature landscapes valley hills mountaisn fields "}]	
				  
    $rootScope.forget_password=function (){	
        $ionicPopup.show({
        template: 'Enter your email address below.<label class="item item-input" style="  height: 34px; margin-top: 10px;"><input  type="email"  /></label>',
        title: 'Forget Password',
        subTitle: ' ',
        scope: $rootScope,
        buttons: [
        {text: '<b>Send</b>',
        type: 'button-positive'},
        { text: 'Cancel' ,
        type: 'button-positive'},]
        });	
    };

 $rootScope.color_bg=false;
  $rootScope.change_them=function(){
		if($rootScope.color_bg){
			$rootScope.color_bg=false
		}else{
			$rootScope.color_bg=true
		}  
	  } 	
	
$rootScope.openPhotoSwipe = function(image) {  
        var index=0;
      
        $rootScope.PhotoSwipe=true;
        var pswpElement = document.querySelectorAll('.pswp')[0];
        var items = []
        items.push({ src:image,w:400,h:300})
        var options = {history:false,focus:false,showAnimationDuration:0,hideAnimationDuration:0};
        var gallery = new PhotoSwipe( pswpElement, PhotoSwipeUI_Default, items, options,index);
        gallery.init();              
    }      
	

  $rootScope.goto=function(url){
	  $location.path(url)
	  }
 $rootScope.myGoBack = function() {
    $ionicHistory.goBack();
  };
	  
  /*************************************menu_modal.html******************/
	$ionicModal.fromTemplateUrl('templates/menumodal.html',function(modal){
	$rootScope.menumodal=modal;
	}, {
		scope: $rootScope,
		animation: 'slide-in-up'
	});
	
	$rootScope.openmenumodal = function(){
		if($location.path()!='/app/register')$rootScope.menumodal.show();
	};
	
	$rootScope.closemenumodal= function() {	
		$rootScope.menumodal.hide();
	};
	$rootScope.$on('$destroy', function() {
		$rootScope.menumodal.remove();
	});
	$rootScope.$on('modal.hidden', function() {
    // Execute action
  });
 /*************************************menu_modal.html******************/
 /*************************************follow.html******************/
	$ionicModal.fromTemplateUrl('templates/follow.html',function(modal){
	$rootScope.follow=modal;
	}, {
		scope: $rootScope,
		animation: 'slide-in-up'
	});
	
	$rootScope.openfollow= function(){
		$rootScope.follow.show();
	};
	
	$rootScope.closefollow= function() {	
		$rootScope.follow.hide();
	};
	$rootScope.$on('$destroy', function() {
		$rootScope.follow.remove();
	});
	$rootScope.$on('modal.hidden', function() {
    // Execute action
  });
 /*************************************follow.html******************/	
		
 /*************************************filter_data.html******************/
	$ionicModal.fromTemplateUrl('templates/filter_data.html',function(modal){
	$rootScope.filter_data=modal;
	}, {
		scope: $rootScope,
		animation: 'slide-in-up'
	});
	
	$rootScope.openfilter_data= function(){
		$rootScope.filter_data.show();
	};
	
	$rootScope.closefilter_data= function() {	
		$rootScope.filter_data.hide();
	};
	$rootScope.$on('$destroy', function() {
		$rootScope.filter_data.remove();
	});
	$rootScope.$on('modal.hidden', function() {
    // Execute action
  });
 /*************************************filter_data.html******************/
  
     /*************************************search_modal.html******************/
	$ionicModal.fromTemplateUrl('templates/search_modal.html',function(modal){
	$rootScope.search_modal=modal;
	}, {
		scope: $rootScope,
		animation: 'slide-in-up'
	});
	
	$rootScope.opensearch_modal= function(){
		$rootScope.search_modal.show();
	};
	
	$rootScope.closesearch_modal= function() {	
		$rootScope.search_modal.hide();
	};
	$rootScope.$on('$destroy', function() {
		$rootScope.search_modal.remove();
	});
	$rootScope.$on('modal.hidden', function() {
    // Execute action
  });
 /*************************************search_modal.html******************/

})

.config(function($stateProvider, $urlRouterProvider,$ionicConfigProvider) {
  $ionicConfigProvider.backButton.text('').previousTitleText('')  ;
   $ionicConfigProvider.navBar.alignTitle('center');
  $stateProvider

  .state('app', {
    url: "/app",
    abstract: true,
    templateUrl: "templates/menu.html"
  })
 .state('start', {
    url: "/start",
        templateUrl: "templates/start.html"
  })



   .state('app.register', {
    url: "/register",
    views: {
      'menuContent': {
        templateUrl: "templates/register.html",controller: 'register'
      }
    }
  })
  
  .state('app.login', {
    url: "/login",
    views: {
      'menuContent': {
        templateUrl: "templates/login.html",controller: 'login'
      }
    }
  })
 

  .state('app.home', {
    url: "/home",
    views: {
      'menuContent': {
        templateUrl: "templates/home.html",controller: 'home'
      }
    }
  })

  .state('app.video', {
    url: "/video",
    views: {
      'menuContent': {
        templateUrl: "templates/video.html",controller: 'video'
      }
    }
  })
   .state('app.setting', {
    url: "/setting",
    views: {
      'menuContent': {
        templateUrl: "templates/setting.html",controller: 'setting'
      }
    }
  })
    .state('app.detail', {
      url: "/detail",
      views: {
        'menuContent': {
          templateUrl: "templates/detail.html",controller: 'detail'
        }
      }
    })

  .state('app.contact', {
      url: "/contact",
      views: {
        'menuContent': {
          templateUrl: "templates/contact.html",controller: 'contact'
        }
      }
    })

  ;
  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/start');
});
